/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoejavaapp;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;


/**
 *
 * @author Patryk
 */
public class TicTacToeJavaApp extends JFrame implements ActionListener {
    
    private TTTWebService_Service service;
    private TTTWebService proxy;
    
    JPanel loginPanel = null;
    JPanel registerPanel = null;
    JPanel gamePanel = null;
    JPanel menuPanel = null;
    
    private final int numberOfRows = 3;
    private final int numberOfPlayers = 2;
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    
    private JTextField[] registerFields;
    
    private int ID;
    private int GAME_ID;
    
    public TicTacToeJavaApp()
    {
        service = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        
        setTitle("Tic-Tac-Toe");
        loginPanel = showLogin();
        this.add(loginPanel);
        this.setVisible(true);
        this.pack();
  
    }
    
    public static void main (String [] args)
    {
       TicTacToeJavaApp app = new TicTacToeJavaApp();
    }
    public JPanel showLogin(){
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        JPanel mainPanel = new JPanel(new GridLayout(3,1));
        
        JPanel user = new JPanel();
        JLabel userLabel = new JLabel("Username: ",JLabel.CENTER);
        usernameField = new JTextField("",10);
        
        user.add(userLabel);
        user.add(usernameField);
        user.setVisible(true);
        
        JPanel password = new JPanel();
        JLabel passwordLabel = new JLabel("Password: ",JLabel.CENTER);
        passwordField = new JPasswordField("",10);
        
        password.add(passwordLabel);
        password.add(passwordField);
        password.setVisible(true);
        
        JPanel control = new JPanel();
        
        JButton btn1 = new JButton("Login");
        btn1.setActionCommand("login");
        btn1.addActionListener(this);
        control.add(btn1);
        
        JButton btn2 = new JButton("Register");
        btn2.setActionCommand("register");
        btn2.addActionListener(this);
        control.add(btn2);
        
        mainPanel.add(user);
        mainPanel.add(password);
        mainPanel.add(control);
        mainPanel.setVisible(true);
        return mainPanel;
        
    }
    
    public JPanel showRegister()
    {
        JPanel mainPanel = null;
        mainPanel = new JPanel(new GridLayout(4,0));
        registerFields = new JTextField[4];
        
        JPanel name = new JPanel();
        JLabel nameLabel = new JLabel("Name: ",JLabel.CENTER);
        JTextField nameField = new JTextField("",10);
        registerFields[0] = nameField;
        name.add(nameField);
        name.add(nameLabel);
        
        JPanel surname = new JPanel();
        JLabel surnameLabel = new JLabel("Surname: ",JLabel.CENTER);
        JTextField surnameField = new JTextField("",10);
        registerFields[1] = surnameField;
        surname.add(surnameField);
        surname.add(surnameLabel);
        
        JPanel username = new JPanel();
        JLabel usernameLabel = new JLabel("Username: ",JLabel.CENTER);
        JTextField usernameFieldReg = new JTextField("",10);
        registerFields[2] = usernameFieldReg;
        username.add(usernameFieldReg);
        username.add(usernameLabel);
        
        JPanel password = new JPanel();
        JLabel passwordLabel = new JLabel("Password: ",JLabel.CENTER);
        JTextField passwordFieldReg = new JTextField("",10);
        registerFields[3] = passwordFieldReg;
        password.add(passwordFieldReg);
        password.add(passwordLabel);
        
        JPanel control = new JPanel();
        
        JButton btn1 = new JButton("Register");
        btn1.setActionCommand("reg");
        btn1.addActionListener(this);
        control.add(btn1);
        
        JButton btn2 = new JButton("Clear");
        btn2.setActionCommand("clear");
        btn2.addActionListener(this);
        control.add(btn2);
        
        mainPanel.add(name);
        mainPanel.add(surname);
        mainPanel.add(username);
        mainPanel.add(password);
        mainPanel.add(control);
        
        return mainPanel;
    }
    
    public JPanel showGame()
    {
        this.setVisible(true);
        
        JPanel mainPanel = null;
        mainPanel = new JPanel(new GridLayout(1,1));
        
        
        JPanel gameP = new JPanel(new GridLayout(3,3));
        for(int i=0;i<numberOfRows;i++)
        {
            for(int j=0;j<numberOfRows;j++)
            {
                JButton btn = new JButton("");
                btn.setBorder(BorderFactory.createLineBorder(Color.RED));
                btn.setActionCommand("Button " + i + " " + j);
                gameP.add(btn,i,j);
            }
        }
        
        JPanel controlP = new JPanel(new GridLayout(4,0));
        JButton startBtn = new JButton("Start");
        JButton quitBtn = new JButton("Quit");
       // JPanel scoreP = new JPanel();
       
        controlP.add(startBtn,0,0);
        controlP.add(quitBtn,1,0);
        
        mainPanel.add(gameP,0,0);
        mainPanel.add(controlP,0,1);
        
        return mainPanel;
    }
    
    public JPanel showMenu()
    {
        JPanel mainPanel = null;
        mainPanel = new JPanel(new GridLayout(1,0));
        
        JPanel controlP = new JPanel();
        
        JButton scoreSystem = new JButton("Score System");
        scoreSystem.setActionCommand("score");
        scoreSystem.addActionListener(this);
        controlP.add(scoreSystem);
        
        JButton leaderboard = new JButton("Leaderboard");
        leaderboard.setActionCommand("leaderboard");
        leaderboard.addActionListener(this);
        controlP.add(leaderboard);
        
        JButton newGame = new JButton("Create Game");
        newGame.setActionCommand("newGame");
        newGame.addActionListener(this);
        controlP.add(newGame);
        
        JButton openGames = new JButton("Open Games");
        openGames.setActionCommand("openGames");
        openGames.addActionListener(this);
        controlP.add(openGames);
        
        mainPanel.add(controlP);
        return mainPanel;
    }

    /*public JPanel showScore()
    {
        
    }*/
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String btnPressed = e.getActionCommand();
        if(btnPressed.equalsIgnoreCase("login"))
        {
            ID = proxy.login(usernameField.getText(),new String (passwordField.getPassword()));
            if(ID > 0)
            {
                this.remove(loginPanel);
                 menuPanel = showMenu();
                 this.add(menuPanel);
                 this.pack();
                 this.validate();
                 this.repaint();
            }else{
                System.out.println("worng credentials");
            }
        }
        else if(btnPressed.equalsIgnoreCase("register"))
        {
            this.remove(loginPanel);
            registerPanel = showRegister();
            this.add(registerPanel);
            this.pack();
            this.validate();
            this.repaint();
            btnPressed = null;
        }else if(btnPressed.equalsIgnoreCase("clear")){
            if(registerFields != null)
            {
                for(int i=0;i < registerFields.length;i++)
                    registerFields[i].setText("");
            }
        } else if(btnPressed.equalsIgnoreCase("reg")){
            if(registerFields != null)
            {
                String name = registerFields[0].getText();
                String surname = registerFields[1].getText();
                String username = registerFields[2].getText();
                String password = registerFields[3].getText();
                String add = "" + (proxy.register(username, password, name, surname));
                if(registerValidation(add))
                {
                    this.remove(registerPanel);
                    loginPanel = showLogin();
                    this.add(loginPanel);
                    this.pack();
                    this.validate();
                    this.repaint();
                }
                
            }
        } else if(btnPressed.equalsIgnoreCase("newGame"))
        {
            this.remove(menuPanel);
            gamePanel = showGame();
            this.add(gamePanel);
            this.pack();
            this.validate();
            this.repaint();
        }
        
        
        /*else if(btnPressed.equalsIgnoreCase("score"))
        {
            this.setVisible(false);
            System.out.println("score works...");
            JPanel scorePanel = showScore();
            this.add(scorePanel);
            this.pack();
            this.validate();
            this.repaint();
        }*/
}
     public boolean registerValidation(String add){
         
          if(add.equals("ERROR-RETRIEVE"))
           {
               return false;
           }
               
           else if(add.equals("ERROR-DB"))
           {
             return false;
           }

           else if(add.equals("ERROR-REPEAT"))
           {
               return false;
           }      
           else
           {
               ID = Integer.parseInt(add);
               return true;
           }    
     }
}
          
